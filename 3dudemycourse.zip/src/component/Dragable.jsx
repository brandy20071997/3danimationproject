
import React from 'react'
import {DragControls} from 'three/examples/jsm/controls/DragControls'
import {extend ,useThree } from 'react-three-fiber';
extend({DragControls})
import { useRef,useEffect,useState} from 'react';

export default function Dragable(props) {
    const groupRef = useRef()
    const controlRef = useRef()
    const [children, setchildren] = useState();
    const {camera,gl,scene} = useThree();
    useEffect(()=>{
            // console.log(groupRef.current)
            setchildren(groupRef.current.children)
            controlRef.current.addEventListener()
    },[])

    useEffect(()=>{
        controlRef.current.addEventListener('hoveron',e=> console.log('you hover'))
    },[children])
    return (
        <group ref={(groupRef)}>
            <dragControls ref={controlRef} args={[children,camera,gl.domElement]}></dragControls>

{props.children}
        </group>
    )
}
